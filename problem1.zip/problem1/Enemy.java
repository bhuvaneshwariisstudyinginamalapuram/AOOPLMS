package problem1;

public abstract class Enemy {
    public abstract void attack();
}
