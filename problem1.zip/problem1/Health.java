package problem1;

public class Health implements Powerup {
    @Override
    public void activate() {
        System.out.println("Increases the HP");
    }
}
