package problem1;

public class HighWeapon implements Weapon {
    @Override
    public void use() {
        System.out.println("This weapon used for Higher attack!");
    }
}

