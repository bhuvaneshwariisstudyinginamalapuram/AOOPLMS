package problem1;

public interface Powerup {
    void activate();
}
