package problem1;

public interface ItemsFactory {
    Weapon newWeapon();
    Powerup newPower();
}
