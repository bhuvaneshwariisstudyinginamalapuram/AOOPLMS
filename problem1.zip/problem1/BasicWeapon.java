package problem1;

public class BasicWeapon implements Weapon {
    @Override
    public void use() {
        System.out.println("This Weapon used with Basic attack!");
    }
}
