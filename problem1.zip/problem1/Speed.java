package problem1;

public class Speed implements Powerup {
    @Override
    public void activate() {
        System.out.println("Increases speed while walking");
    }
}

