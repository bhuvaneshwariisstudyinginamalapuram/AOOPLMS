package problem1;

public class EasyEnemy extends Enemy {
    @Override
    public void attack() {
        System.out.println("Attacks with less damage");
    }
}