package problem1;


public class HardEnemy extends Enemy {
    @Override
    public void attack() {
        System.out.println("Attacks with high damage");
    }
}
