package problem1;

public interface Weapon {
    void use();
}
